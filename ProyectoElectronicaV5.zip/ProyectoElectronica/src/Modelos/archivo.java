/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFileChooser;

/**
 *
 * @author araag
 */
public class archivo  {

    ArrayList<String> lista = new ArrayList<String>();
    JFileChooser fileChooser = new JFileChooser();
    
    
    public ArrayList<String> inicializar() throws FileNotFoundException
    {
        fileChooser.showOpenDialog(fileChooser);
        String ruta = fileChooser.getSelectedFile().getAbsolutePath();   
        File doc = new File(ruta);
        Scanner obj = new Scanner(doc);
        while (obj.hasNextLine())
            lista.add(obj.nextLine());
        
        return lista;
    }
}
