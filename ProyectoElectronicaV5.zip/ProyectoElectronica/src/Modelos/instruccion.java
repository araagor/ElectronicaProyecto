/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.util.Hashtable;
import javax.swing.JOptionPane;

/**
 *
 * @author araag
 */
public class instruccion {
    
        Hashtable instrucciones;
        String instruccion;
        registros registros;
    public instruccion(String instruccion, registros registro) {
        instrucciones = new Hashtable();
        instrucciones.put("mov", "00000000");
        instrucciones.put("add", "00000001");
        instrucciones.put("sub", "00000010");
        instrucciones.put("mul", "00000011");
        instrucciones.put("div", "00000100");
        instrucciones.put("and", "00000101");
        instrucciones.put("or",  "00000110");
        instrucciones.put("xor", "00000111");
        instrucciones.put("not", "00001000");
        this.instruccion=instruccion;
        this.registros = registro;
        hacerInstruccion();
    }
    
    public void hacerInstruccion()
    {
        String[] cadena;
        cadena = instruccion.split(" ");
        
        if(cadena[0].equals("mov"))
        {
            registros.setLenguajeMaquina((String) instrucciones.get("mov"));
            mov(cadena[1], cadena[2]);
            
            
           
        }
        else if(cadena[0].equals("add"))
        {
            registros.setLenguajeMaquina((String) instrucciones.get("add"));
            add(cadena[1], cadena[2]);
            
            
        }
        else if(cadena[0].equals("sub"))
        {
            registros.setLenguajeMaquina((String) instrucciones.get("sub"));
            sub(cadena[1], cadena[2]);
            
        }
        else if(cadena[0].equals("mul"))
        {
            registros.setLenguajeMaquina((String) instrucciones.get("mul"));
            mul(cadena[1]);
            
        }
        else if(cadena[0].equals("div"))
        {
             registros.setLenguajeMaquina((String) instrucciones.get("div"));
            div(cadena[1]);
           
        }
        else if(cadena[0].equals("not"))
        {
            registros.setLenguajeMaquina((String) instrucciones.get("not"));
            not(cadena[1]);
        }
        else if(cadena[0].equals("and"))
        {
            registros.setLenguajeMaquina((String) instrucciones.get("and"));
            and(cadena[1], cadena[2]);
        }
        else if(cadena[0].equals("or"))
        {
            registros.setLenguajeMaquina((String) instrucciones.get("or"));
            or(cadena[1], cadena[2]);
        }
        else if(cadena[0].equals("xor"))
        {
            registros.setLenguajeMaquina((String) instrucciones.get("xor"));
            xor(cadena[1], cadena[2]);
        }      
    }
    public void xor(String v1, String v2)
    {
        String xor="";
        boolean trabajo1 = true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                
                for(int a=0; a<registros.getRegistros().size();a++)
                {
                    if(registros.getRegistros().get(a).getNombre().equals(v2))
                    {
                        trabajo1 = false;
                        String cadena1 = registros.conversor(registros.getRegistros().get(i).getValor());
                        String cadena2 = registros.conversor(registros.getRegistros().get(a).getValor());
                        for(int q = 0; q<cadena1.length();q++)
                        {
                            if(cadena1.charAt(q)==cadena2.charAt(q))
                            {
                                xor+="0";
                            }
                            else
                            {
                                xor+="1";
                            }
                        }
                        System.out.println(cadena1+ "\n"+cadena2+"\n"+xor);
                    }
                    
                }
                if(trabajo1)
                {
                     String cadena1 = registros.conversor(registros.getRegistros().get(i).getValor());
                     String cadena2 = registros.conversor(Integer.parseInt(v2));
                     for(int q = 0; q<cadena1.length();q++)
                        {
                            if(cadena1.charAt(q)==cadena2.charAt(q))
                            {
                                xor+="0";
                            }
                            else
                            {
                                xor+="1";
                            }
                        }
                     System.out.println(cadena1+ "\n"+cadena2+"\n"+xor);
                     
                }
            }
        }
        
    }
    public void or(String v1, String v2)
    {
        String or="";
        boolean trabajo1 = true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                
                for(int a=0; a<registros.getRegistros().size();a++)
                {
                    if(registros.getRegistros().get(a).getNombre().equals(v2))
                    {
                        trabajo1 = false;
                        String cadena1 = registros.conversor(registros.getRegistros().get(i).getValor());
                        String cadena2 = registros.conversor(registros.getRegistros().get(a).getValor());
                        for(int q = 0; q<cadena1.length();q++)
                        {
                            if(cadena1.charAt(q)==cadena2.charAt(q) && cadena1.charAt(q) == 48)
                            {
                                or+="0";
                            }
                            else
                            {
                                or+="1";
                            }
                        }
                        System.out.println(cadena1+ "\n"+cadena2+"\n"+or);
                    }
                    
                }
                if(trabajo1)
                {
                     String cadena1 = registros.conversor(registros.getRegistros().get(i).getValor());
                     String cadena2 = registros.conversor(Integer.parseInt(v2));
                     for(int q = 0; q<cadena1.length();q++)
                        {
                            if(cadena1.charAt(q)==cadena2.charAt(q) && cadena1.charAt(q) == 48)
                            {
                                or+="0";
                            }
                            else
                            {
                                or+="1";
                            }
                        }
                     System.out.println(cadena1+ "\n"+cadena2+"\n"+or);
                     
                }
            }
        }
        
    }
    public void and(String v1, String v2)
    {
        String and="";
        boolean trabajo1 = true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                
                for(int a=0; a<registros.getRegistros().size();a++)
                {
                    if(registros.getRegistros().get(a).getNombre().equals(v2))
                    {
                        trabajo1 = false;
                        String cadena1 = registros.conversor(registros.getRegistros().get(i).getValor());
                        String cadena2 = registros.conversor(registros.getRegistros().get(a).getValor());
                        for(int q = 0; q<cadena1.length();q++)
                        {
                            if(cadena1.charAt(q)==cadena2.charAt(q) && cadena1.charAt(q) == 49)
                            {
                                and+="1";
                            }
                            else
                            {
                                and+="0";
                            }
                        }
                        System.out.println(cadena1+ "\n"+cadena2+"\n"+and);
                    }
                    
                }
                if(trabajo1)
                {
                     String cadena1 = registros.conversor(registros.getRegistros().get(i).getValor());
                     String cadena2 = registros.conversor(Integer.parseInt(v2));
                     for(int q = 0; q<cadena1.length();q++)
                        {
                            if(cadena1.charAt(q)==cadena2.charAt(q) && cadena1.charAt(q) == 49)
                            {
                                and+="1";
                            }
                            else
                            {
                                and+="0";
                            }
                        }
                     System.out.println(cadena1+ "\n"+cadena2+"\n"+and);
                     
                }
            }
        }
        
    }
    public void not(String v1)
    {
        String not="";
        boolean trabajo = true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                trabajo = false;
                String cadena;
                cadena = registros.conversor(registros.getRegistros().get(i).getValor());
                char cero = 0;
                
                
                for(int a=0; a<cadena.length();a++)
                {
                    
                    if(cadena.charAt(a)== cero)
                    {
                      not=not+"1";  
                    }
                    else
                    {
                        not=not+"0";
                    }
                }
                
            }
        }
        if(trabajo)
        {
              String cadena;
                cadena = registros.conversor(Integer.parseInt(v1));
                char cero = 48;
                
                
                for(int a=0; a<cadena.length();a++)
                {
                    System.out.println(cadena.charAt(a));
                    if(cadena.charAt(a)== cero)
                    {
                      not=not+"1";  
                    }
                    else
                    {
                        not=not+"0";
                    }
                }
        }
        System.out.println("Este es el not: " + not);
    }
    public void div(String v1)
    {
        boolean trabajo = true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                
                registros.getRegistros().get(1).setValor(registros.getRegistros().get(0).getValor()/registros.getRegistros().get(i).getValor());
                registros.setLenguajeMaquina(registros.getRegistros().get(i).getId());
                trabajo=false;
            }
        }
        if(trabajo)
        {
            registros.getRegistros().get(1).setValor(registros.getRegistros().get(0).getValor()/Integer.parseInt(v1));
            registros.setLenguajeMaquina(registros.conversor(Integer.parseInt(v1)));
        }
    }
    public void mul(String v1)
    {
        boolean trabajo = true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                
                registros.getRegistros().get(1).setValor(registros.getRegistros().get(i).getValor()*registros.getRegistros().get(0).getValor());
                registros.setLenguajeMaquina(registros.getRegistros().get(i).getId());
                trabajo=false;
            }
        }
        if(trabajo)
        {
            registros.getRegistros().get(1).setValor(Integer.parseInt(v1)*registros.getRegistros().get(0).getValor());
            registros.setLenguajeMaquina(registros.conversor(Integer.parseInt(v1)));
        }
        
    }
    public void sub(String v1, String v2)
    {
        boolean trabajo = true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                
                    for(int a=0; a<registros.getRegistros().size();a++ )
                    {
                        if(registros.getRegistros().get(a).getNombre().equals(v2))
                        {
                            
                            int suma1 = registros.getRegistros().get(i).getValor();
                            registros.setLenguajeMaquina(registros.getRegistros().get(i).getId());
                            int suma2 = registros.getRegistros().get(a).getValor();
                            registros.setLenguajeMaquina(registros.getRegistros().get(a).getId());
                            registros.getRegistros().get(i).setValor(suma1-suma2);
                            trabajo = false;
                            
                        }
                    }
                    if(trabajo)
                    {
                        registros.getRegistros().get(i).setValor(registros.getRegistros().get(i).getValor()-Integer.parseInt(v2));
                        registros.setLenguajeMaquina(registros.getRegistros().get(i).getId());
                        registros.setLenguajeMaquina(registros.conversor(Integer.parseInt(v2)));
                    }
            }
            
        }
    }
    public void add(String v1, String v2)
    {
        boolean trabajo = true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                
                    for(int a=0; a<registros.getRegistros().size();a++ )
                    {
                        if(registros.getRegistros().get(a).getNombre().equals(v2))
                        {
                            
                            int suma1 = registros.getRegistros().get(i).getValor();
                            registros.setLenguajeMaquina(registros.getRegistros().get(i).getId());
                            int suma2 = registros.getRegistros().get(a).getValor();
                            registros.setLenguajeMaquina(registros.getRegistros().get(a).getId());
                            registros.getRegistros().get(i).setValor(suma1+suma2);
                            trabajo = false;
                            
                        }
                    }
                    if(trabajo)
                    {
                        registros.getRegistros().get(i).setValor(registros.getRegistros().get(i).getValor()+Integer.parseInt(v2));
                        registros.setLenguajeMaquina(registros.getRegistros().get(i).getId());
                        registros.setLenguajeMaquina(registros.conversor(Integer.parseInt(v2)));
                    }
            }
            
        }
    }
    public void mov(String v1, String v2)
    {
        
        boolean trabajo=true;
        boolean trabajo1=true;
        for(int i=0; i<registros.getRegistros().size(); i++)
        {
            if(registros.getRegistros().get(i).getNombre().equals(v1))
            {
                trabajo=false;
                for(int a=0; a<registros.getRegistros().size();a++)
                {
                if(registros.getRegistros().get(a).getNombre().equals(v2))
                {
                    registros.getRegistros().get(i).setValor(registros.getRegistros().get(a).getValor());
                    trabajo1 = false;
                    registros.setLenguajeMaquina(registros.getRegistros().get(i).getId());
                    registros.setLenguajeMaquina(registros.getRegistros().get(a).getId());
                 
                }
                
                }
                if(trabajo1)
                {
                    registros.getRegistros().get(i).setValor(Integer.parseInt(v2));
                    
                    registros.setLenguajeMaquina(registros.getRegistros().get(i).getId());
                    
                    registros.setLenguajeMaquina(registros.conversor(Integer.parseInt(v2)));
                    
                    
                }
            }
            
        }
        if(trabajo)
        {
            for(int i=0; i<registros.getRegistros().size();i++)
            {
                
            
                String binario="00001000";
                for(int x=0; x<registros.getRegistros().size(); x++)
                {
                    if(registros.getRegistros().get(x).getId().equals(binario))
                    {
                        int binint = Integer.parseInt(binario);
                        binint++;
                        binario = "0000" + binint;
                        
                        
                    }
                }
                registros.setLenguajeMaquina(binario);
                registros.setLenguajeMaquina(registros.conversor(Integer.parseInt(v2)));
                registro r = new registro(binario, v1, Integer.parseInt(v2) );
                registros.getRegistros().add(r);
                i = registros.getRegistros().size();
            }
            }
        
    }
  
}
