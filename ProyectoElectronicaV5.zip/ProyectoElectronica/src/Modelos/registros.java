/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.util.ArrayList;

/**
 *
 * @author araag
 */
public class registros {
    ArrayList<registro> registros = new ArrayList<registro>();
    String lenguajeMaquina;
    int cont;

    public registros() {
        this.lenguajeMaquina = "";
        cont=0;
    }

    public ArrayList<registro> getRegistros() {
        return registros;
    }

    public void setRegistros(ArrayList<registro> registros) {
        this.registros = registros;
    }

    public String getLenguajeMaquina() {
        return lenguajeMaquina;
    }

    public void setLenguajeMaquina(String lenguajeMaquina1) {
        this.lenguajeMaquina =   this.lenguajeMaquina +lenguajeMaquina1;
        cont++;
        if(cont==10)
        {
            this.lenguajeMaquina = this.lenguajeMaquina + "\n";
            cont=0;
        }
    }
    public String conversor(int numero)
    {
        String signo;
        String binario  ="";
        int respaldo;
        if(numero<0)
            signo="1";
        else
            signo="0";
        respaldo = Math.abs(numero);
        do
        {
            
           binario = binario + respaldo%2;
           respaldo=respaldo/2;
           
        }while(respaldo!= 1 && respaldo != 0);
        binario= binario+respaldo;
        String ceros="";
        if(binario.length()<7)
        {
            
            for(int i=binario.length();i<7 ; i++)
            {
                ceros= "0"+ ceros;
            }
            
        }
        StringBuilder binary = new StringBuilder(binario);
        binario= binary.reverse().toString();
        binario=ceros+binario;
        binario=signo+binario;
        System.out.println("La conversion de "+ numero + " es " + binario);
        return binario;
    }
    
    
}
